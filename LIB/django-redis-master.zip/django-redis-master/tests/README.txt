For run tests install hiredis and put you redis listen on unix sockets.
After this, run this command:

    python runtests.py
    python runtests.py <appName>.<TestClass>.<MethodName>
